package com.csse3200.game.entities.configs;

public class RicochetTowerConfig {
    public int health = 1;
    public int baseAttack = 0;
    public int cost = 1;
}
