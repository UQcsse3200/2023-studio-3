package com.csse3200.game.entities.configs;

public class FireTowerConfig {
    public int health = 1;
    public int baseAttack = 0;
    public int cost = 1;

    public float attackRate = 1;
}
