package com.csse3200.game.entities.configs;

public class FireworksTowerConfig {
    public int health = 1;
    public int baseAttack = 0;
    public int cost = 1;
    public int attackRate =0;
    public int incomeRate =0;
}
